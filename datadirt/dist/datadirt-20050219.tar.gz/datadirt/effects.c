#include <math.h>

#include "externs.h"

