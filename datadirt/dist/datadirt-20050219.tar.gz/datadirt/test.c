#include <stdio.h>
#include <jack/jack.h>
#include <sndfile.h>
#include "audio.h"

int main (void) {
  t_head *head;
  head = &heads[0];
  return(0);
}
