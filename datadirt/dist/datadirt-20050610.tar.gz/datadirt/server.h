
extern int server_init(void);
