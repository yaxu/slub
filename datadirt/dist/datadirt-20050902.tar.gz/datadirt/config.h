/* Use jack?  Add -ljack to the CFLAGS in the Makefile if so */

/* #define USE_JACK 1 */

#define DEVDSP     "/dev/dsp"

/* datadirt will look for samples here */
#define SAMPLEROOT "/yaxu/samples"
